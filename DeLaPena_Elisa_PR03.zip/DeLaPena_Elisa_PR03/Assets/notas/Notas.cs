using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Notas : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

   
    /* NOTAS
     
     
     movimiento con flechas. 

    correr con shift

    crouch ctrl o flecha abajo

    roll alt
     
     
     
     
     
     
     
     
     
     
     */
}
